<script setup lang="ts">
import { Head, useForm } from '@inertiajs/vue3'

const getError = (error: any, key: string) => {
  return error?.[key]?.join(',')
}

const form = useForm<FormDetails>({
  // name: '',
  // email: '',
  // bankDetails: {
  //   accountNumber: '',
  //   routingNumber: '',
  //   nameOnAccount: '',
  //   address: {
  //     city: '',
  //     deep: {
  //       mountain: '',
  //     },
  //   },
  // },
  // file: undefined,
  // skills: [''],
  // images: [
  //   {
  //     caption: '',
  //     file: undefined,
  //   },
  // ],
  images: [{ file: undefined, title: '' }],
})
</script>

<template>
  <Head>
    <title>Home</title>
  </Head>
  <h1>Login</h1>
  <div>
    <form
      @submit.prevent="form.post('/login')"
      style="display: flex; flex-direction: column; gap: 1rem; padding: 3rem"
    >
      <!-- <input type="text" placeholder="Name" v-model="form.name" />
      <span>{{ getError(form.errors, 'name') }}</span>
      <input type="text" placeholder="Email" v-model="form.email" />
      <span>{{ getError(form.errors, 'email') }}</span>
      <input type="text" placeholder="Account Number" v-model="form.bankDetails.accountNumber" />
      <span>{{ getError(form.errors, 'bankDetails.accountNumber') }}</span>
      <input type="text" placeholder="Routing Number" v-model="form.bankDetails.routingNumber" />
      <span>{{ getError(form.errors, 'bankDetails.routingNumber') }}</span>
      <input type="text" placeholder="Name on Account" v-model="form.bankDetails.nameOnAccount" />
      <span>{{ getError(form.errors, 'bankDetails.nameOnAccount') }}</span>
      <input type="text" placeholder="City" v-model="form.bankDetails.address.city" />
      <span>{{ getError(form.errors, 'bankDetails.address.city') }}</span>
      <input type="text" placeholder="Mountain" v-model="form.bankDetails.address.deep.mountain" />
      <span>{{ getError(form.errors, 'bankDetails.address.deep.mountain') }}</span>
      <input
        type="file"
        placeholder="Caption"
        @input="form.file = ($event.target as HTMLInputElement)?.files?.[0]"
      />
      <span>{{ getError(form.errors, 'file') }}</span>
      <br />
      <template v-for="(_, index) in form.skills" :key="index">
        <input type="text" placeholder="Skill" v-model="form.skills[index]" />
        <span>{{ getError(form.errors, `skills.${index}`) }}</span>
      </template>
      <button type="button" @click="form.skills.push('')">Add skill</button> -->
      <template v-for="(_, index) in form.images" :key="index">
        <input type="text" placeholder="Caption" v-model="form.images[index].title" />
        <span>{{ getError(form.errors, `images.${index}.title`) }}</span>
        <input
          type="file"
          placeholder="Caption"
          @input="form.images[index].file = ($event.target as HTMLInputElement)?.files?.[0]"
        />
        <span>{{ getError(form.errors, `images.${index}.file`) }}</span>
      </template>
      <button type="button" @click="form.images.push({ file: undefined, title: '' })">
        Add image
      </button>
      <button type="submit" :disabled="form.processing">Submit</button>
    </form>
  </div>
</template>
