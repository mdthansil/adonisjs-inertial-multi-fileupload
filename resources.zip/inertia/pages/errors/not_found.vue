<template>
  <div class="container">
    <div class="title">Page not found</div>

    <span>This page does not exist.</span>
  </div>
</template>