type FormDetails = {
  // name: string
  // email: string
  // bankDetails: {
  //   accountNumber: string
  //   routingNumber: string
  //   nameOnAccount: string
  //   address: {
  //     city: string
  //     deep: {
  //       mountain: string
  //     }
  //   }
  // }
  // file: File | undefined
  // skills: string[]
  // images: {
  //   caption: string
  //   file: File | undefined
  // }[]
  images: { file: File | undefined; title: string }[]
}
