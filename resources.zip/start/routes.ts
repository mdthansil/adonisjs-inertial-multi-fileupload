/*
|--------------------------------------------------------------------------
| Routes file
|--------------------------------------------------------------------------
|
| The routes file is used for defining the HTTP routes.
|
*/

import router from '@adonisjs/core/services/router'
import vine, { SimpleMessagesProvider } from '@vinejs/vine'
router.on('/').renderInertia('home')

router.post('/login', async ({ request, response }) => {
  const { images } = await request.validateUsing(
    vine.compile(
      vine.object({
        // name: vine.string(),
        // email: vine.string(),
        // bankDetails: vine.object({
        //   accountNumber: vine.string(),
        //   routingNumber: vine.string(),
        //   nameOnAccount: vine.string(),
        //   address: vine.object({
        //     city: vine.string(),
        //     deep: vine.object({
        //       mountain: vine.string(),
        //     }),
        //   }),
        // }),

        // file: vine.file({ size: 100000 }),
        // skills: vine.array(vine.string().minLength(2)),
        // images: vine.array(
        //   vine.object({
        //     caption: vine.string(),
        //     file: vine.file({ size: 1000000 }),
        //   })
        // ),
        images: vine.array(vine.object({ file: vine.file({ size: '2mb' }), title: vine.string() })),
      })
    )
    // {
    //   messagesProvider: new SimpleMessagesProvider(
    //     {
    //       'skills.*.required': 'Skill is required',
    //       // 'images.*.caption.required': 'Caption is required',
    //       // 'images.*.file.required': 'File is required',
    //     },
    //     { 'skills.*': 'skill' }
    //   ),
    // }
  )
  try {
    console.log('sdfsdfdsf', images)
    console.log(request.all())
    console.log(request.allFiles())
    // return response.json(request.all())
    return response.redirect().back()
  } catch (error) {
    console.log(error)
    return response.redirect().back()
  }
})
